# UCL-App-Project-Brain-Focus
1st year Computer Science students working on a waveform comparison solution.
